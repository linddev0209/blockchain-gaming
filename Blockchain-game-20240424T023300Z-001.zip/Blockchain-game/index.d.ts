declare module 'buffer-layout'
declare module 'bn.js'